package me.mythforge.gacha;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public class MythForgeGacha extends JavaPlugin implements Listener {

    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private static final long COOLDOWN_TIME = 60 * 60 * 1000;

    private final List<Material> rewards = Arrays.asList(
            Material.DIAMOND_SWORD,
            Material.IRON_SWORD,
            Material.GOLDEN_SWORD,
            Material.DIAMOND,
            Material.EMERALD
    );

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("MythForgeGacha ENABLED");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player player)) return true;

        if (command.getName().equalsIgnoreCase("summongachanpc")) {
            Villager npc = player.getWorld().spawn(player.getLocation(), Villager.class);
            npc.setCustomName("§6§lGacha NPC");
            npc.setCustomNameVisible(true);
            npc.setAI(false);
            npc.setInvulnerable(true);
            npc.addScoreboardTag("GACHA_NPC");

            player.sendMessage("§aGacha NPC summoned!");
            return true;
        }

        if (command.getName().equalsIgnoreCase("gachareset")) {
            if (!player.isOp()) {
                player.sendMessage("§cNo permission.");
                return true;
            }

            if (args.length != 1) {
                player.sendMessage("§cUsage: /gachareset <player>");
                return true;
            }

            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                player.sendMessage("§cPlayer not found.");
                return true;
            }

            cooldowns.remove(target.getUniqueId());
            player.sendMessage("§aGacha cooldown reset for " + target.getName());
            return true;
        }

        return true;
    }

    @EventHandler
    public void onNpcClick(PlayerInteractEntityEvent event) {
        Entity entity = event.getRightClicked();
        Player player = event.getPlayer();

        if (!(entity instanceof Villager villager)) return;
        if (!villager.getScoreboardTags().contains("GACHA_NPC")) return;

        long now = System.currentTimeMillis();
        long last = cooldowns.getOrDefault(player.getUniqueId(), 0L);

        if (now - last < COOLDOWN_TIME) {
            long minutesLeft = (COOLDOWN_TIME - (now - last)) / 1000 / 60;
            player.sendMessage("§cWait " + minutesLeft + " minutes before next gacha.");
            return;
        }

        Material reward = rewards.get(new Random().nextInt(rewards.size()));
        player.getInventory().addItem(new ItemStack(reward));
        cooldowns.put(player.getUniqueId(), now);

        player.sendMessage("§6You pulled: §e" + reward.name());
    }
}